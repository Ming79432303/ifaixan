//
//  LGArticleCell.h
//  ifaxian
//
//  Created by ming on 16/11/22.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LGArticleModel.h"
#import "LGShareImage.h"
@interface LGArticleCell : UITableViewCell
@property(nonatomic, strong) LGShareImage *postModel;
@end
