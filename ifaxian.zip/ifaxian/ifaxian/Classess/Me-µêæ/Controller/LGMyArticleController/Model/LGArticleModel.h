//
//  LGArticleModel.h
//  ifaxian
//
//  Created by ming on 16/11/22.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGPostModel.h"

@interface LGArticleModel : LGPostModel
@property(nonatomic, assign) CGFloat articleCellHeight;

@end
