//
//  LGOtherNone.m
//  ifaxian
//
//  Created by ming on 16/12/14.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGOtherNone.h"

@implementation LGOtherNone

@end
