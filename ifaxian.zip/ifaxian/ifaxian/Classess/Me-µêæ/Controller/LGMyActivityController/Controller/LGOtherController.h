//
//  LGMyActivityController.h
//  ifaxian
//
//  Created by ming on 16/11/21.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGBasiController.h"

@interface LGOtherController : UITableViewController

@end
