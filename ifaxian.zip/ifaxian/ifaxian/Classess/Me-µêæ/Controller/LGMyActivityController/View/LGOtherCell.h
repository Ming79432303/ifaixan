//
//  LGOtherCell.h
//  ifaxian
//
//  Created by ming on 16/12/14.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LGOther.h"
@interface LGOtherCell : UITableViewCell
@property(nonatomic, strong) LGOther *model;
@end
