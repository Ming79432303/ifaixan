//
//  LGSendArticleContrloler.h
//  ifaxian
//
//  Created by ming on 16/12/5.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGEditorController.h"

@interface LGSendArticleContrloler : LGEditorController

@end
