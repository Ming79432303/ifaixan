//
//  LGSendVideoController.h
//  ifaxian
//
//  Created by ming on 16/12/2.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LGSendVideoController : UIViewController

@end
