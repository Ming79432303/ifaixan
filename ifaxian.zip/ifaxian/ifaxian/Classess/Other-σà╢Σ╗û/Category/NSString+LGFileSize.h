//
//  NSString+HSYFileSize.h
//  百思不得姐
//
//  Created by ming on 16/11/5.
//  Copyright © 2016年 Apple_Lzzy27. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (LGFileSize)
///计算文件的大小
- (unsigned long long)lg_fileSize;
@end
