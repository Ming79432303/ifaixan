//
//  UIButton+AlphaImage.h
//  微博个人详情
//
//  Created by ming on 17/8/16.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (AlphaImage)

+ (UIImage *)imageWithAlpha:(CGFloat )alpha;
+ (UIImage *)WhiteimageWithAlpha:(CGFloat )alpha;
@end
