//
//  NSCalendar+Calendar.h
//  时间处理
//
//  Created by ming on 16/11/8.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSCalendar (LGExtension)
+(instancetype)lg_calendar;
@end
