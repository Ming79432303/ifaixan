//
//  UITextField+HSYTextField.h
//  百思不得姐
//
//  Created by ming on 16/11/3.
//  Copyright © 2016年 Apple_Lzzy27. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (LGTextField)
@property(nonatomic, strong) UIColor *lg_placeholderColor;
@end
