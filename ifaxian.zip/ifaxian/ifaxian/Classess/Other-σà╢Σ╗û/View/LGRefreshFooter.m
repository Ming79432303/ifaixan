//
//  LGRefreshFooter.m
//  ifaxian
//
//  Created by ming on 16/11/17.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGRefreshFooter.h"

@implementation LGRefreshFooter

- (void)prepare{
    [super prepare];
    
}

@end
