//
//  LGRefreshHeader.h
//  ifaxian
//
//  Created by Apple_Lzzy27 on 16/11/19.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface LGRefreshHeader : MJRefreshStateHeader

@end
