//
//  LGTag.h
//  ifaxian
//
//  Created by ming on 16/11/28.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGBasiModel.h"

@interface LGTag : LGBasiModel

@end
