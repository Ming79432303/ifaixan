//
//  LGCategory.h
//  ifaxian
//
//  Created by ming on 16/11/28.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LGBasiModel : NSObject
@property(nonatomic, copy) NSString *slug;
@property(nonatomic, copy) NSString *describe;
@property(nonatomic, copy) NSString *post_count;
@property(nonatomic, copy) NSString *title;
@property(nonatomic, copy) NSString *ID;
@end
