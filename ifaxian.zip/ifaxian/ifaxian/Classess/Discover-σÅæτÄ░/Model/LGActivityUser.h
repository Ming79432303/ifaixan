//
//  LGActivityUser.h
//  ifaxian
//
//  Created by ming on 16/12/17.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LGActivityUser : NSObject
@property(nonatomic, copy) NSString *username;
@property(nonatomic, copy) NSString *display_name;
@end
