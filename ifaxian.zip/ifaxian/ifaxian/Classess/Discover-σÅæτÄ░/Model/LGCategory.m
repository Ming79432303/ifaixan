//
//  LGCategory.m
//  ifaxian
//
//  Created by ming on 16/11/28.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGCategory.h"

@implementation LGCategory

@end
