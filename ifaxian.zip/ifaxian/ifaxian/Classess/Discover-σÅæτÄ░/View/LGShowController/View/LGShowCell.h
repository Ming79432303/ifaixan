//
//  LGShowCell.h
//  ifaxian
//
//  Created by ming on 16/11/27.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LGShowCell : UITableViewCell

@end
