//
//  flowLayout.h
//  图片浏览相册
//
//  Created by ming on 26/7/16.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LGFlowLayout : UICollectionViewFlowLayout

@end
