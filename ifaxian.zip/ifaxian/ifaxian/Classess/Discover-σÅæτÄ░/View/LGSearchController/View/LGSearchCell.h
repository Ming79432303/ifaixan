//
//  LGSearchCell.h
//  ifaxian
//
//  Created by ming on 16/11/26.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LGPostModel.h"
@interface LGSearchCell : UITableViewCell
@property(nonatomic, strong) LGPostModel *model;
@end
