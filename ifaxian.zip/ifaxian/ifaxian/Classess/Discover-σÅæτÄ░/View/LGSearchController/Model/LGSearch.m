//
//  LGSearch.m
//  ifaxian
//
//  Created by ming on 16/12/17.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGSearch.h"

@implementation LGSearch

@end
