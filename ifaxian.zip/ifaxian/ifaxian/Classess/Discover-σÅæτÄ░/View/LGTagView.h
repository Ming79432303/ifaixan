//
//  LGTagView.h
//  标签
//
//  Created by ming on 16/11/29.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LGTag.h"
@interface LGTagView : UIView
@property(nonatomic, strong) NSArray<LGTag *> *tags;

@end
