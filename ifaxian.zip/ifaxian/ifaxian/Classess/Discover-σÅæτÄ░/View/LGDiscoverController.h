//
//  LGDiscoverController.h
//  ifaxian
//
//  Created by ming on 16/11/17.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGBasiController.h"

@interface LGDiscoverController : LGBasiController

@end
