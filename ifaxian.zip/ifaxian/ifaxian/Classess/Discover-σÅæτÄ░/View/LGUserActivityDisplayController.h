//
//  LGUserActivityDisplayController.h
//  ifaxian
//
//  Created by ming on 16/12/18.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGBasiController.h"

@interface LGUserActivityDisplayController : LGBasiController
@property(nonatomic, copy) NSString *postUrl;
@end
