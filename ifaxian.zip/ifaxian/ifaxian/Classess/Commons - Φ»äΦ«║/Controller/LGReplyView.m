//
//  LGreplyView.m
//  ifaxian
//
//  Created by Apple_Lzzy27 on 16/11/19.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGReplyView.h"

@implementation LGReplyView


- (void)awakeFromNib{
    [super awakeFromNib];
    self.autoresizingMask = UIViewAutoresizingNone;
    
}

@end
