//
//  LGSetingController.h
//  ifaxian
//
//  Created by ming on 16/12/10.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGBasiController.h"

@interface LGSetingController : LGBasiController

@end
