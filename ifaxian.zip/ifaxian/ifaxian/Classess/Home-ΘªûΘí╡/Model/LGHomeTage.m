//
//  LGHomeTage.m
//  ifaxian
//
//  Created by ming on 16/12/6.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGHomeTage.h"

@implementation LGHomeTage

@end
