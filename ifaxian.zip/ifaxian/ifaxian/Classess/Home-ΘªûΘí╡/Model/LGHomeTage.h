//
//  LGHomeTage.h
//  ifaxian
//
//  Created by ming on 16/12/6.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGBasiModel.h"

@interface LGHomeTage : LGBasiModel

@end
