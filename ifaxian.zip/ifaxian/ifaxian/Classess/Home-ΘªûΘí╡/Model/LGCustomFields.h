//
//  LGcustomFields.h
//  ifaxian
//
//  Created by Apple_Lzzy27 on 16/11/17.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LGCustomFields : NSObject

@property(nonatomic, strong) NSArray *bigfa_ding;
@property(nonatomic, strong) NSArray *post_views_count;
@end
