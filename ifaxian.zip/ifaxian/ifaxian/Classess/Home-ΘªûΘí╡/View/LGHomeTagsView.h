//
//  LGHomeTagsView.h
//  ifaxian
//
//  Created by ming on 16/12/6.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LGHomeTage.h"
@interface LGHomeTagsView : UIView
@property (nonatomic, strong) NSArray<LGHomeTage *> *tags;
@end
