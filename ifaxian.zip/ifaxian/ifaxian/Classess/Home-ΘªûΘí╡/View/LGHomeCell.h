//
//  LGVHomeCell.h
//  ifaxian
//
//  Created by ming on 16/11/17.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LGHomeModel.h"

@interface LGHomeCell : UITableViewCell

@property (nonatomic ,strong) LGHomeModel *model;


@end
