//
//  LGHomeImagesView.h
//  ifaxian
//
//  Created by ming on 16/12/9.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LGHomeModel.h"
@interface LGHomeImagesView : UIView
@property(nonatomic, strong) NSArray *images;
@end
