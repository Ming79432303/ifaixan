//
//  LGHomeCommntContentView.h
//  ifaxian
//
//  Created by ming on 16/12/6.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LGComment.h"
@interface LGHomeCommntContentView : UIView
@property(nonatomic, strong) LGComment *comment;
@end
