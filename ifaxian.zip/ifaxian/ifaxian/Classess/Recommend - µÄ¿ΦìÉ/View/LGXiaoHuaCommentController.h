//
//  LGXiaoHuaCommentController.h
//  ifaxian
//
//  Created by ming on 16/12/7.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGCommentController.h"
#import "LGRecommend.h"
@interface LGXiaoHuaCommentController : LGCommentController
@property(nonatomic, strong) LGRecommend *share;
@end
