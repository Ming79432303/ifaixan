//
//  LGDongManController.h
//  ifaxian
//
//  Created by ming on 16/12/7.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LGTopicController.h"
@interface LGTopicDongManController : LGTopicController

@end
