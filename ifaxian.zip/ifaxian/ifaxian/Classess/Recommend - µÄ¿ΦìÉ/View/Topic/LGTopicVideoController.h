//
//  LGTopicVideoController.h
//  ifaxian
//
//  Created by ming on 16/12/8.
//  Copyright © 2016年 ming. All rights reserved.
//

#import "LGTopicController.h"

@interface LGTopicVideoController : LGTopicController

@end
